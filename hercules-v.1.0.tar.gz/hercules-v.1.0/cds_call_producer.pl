#!/usr/bin/perl

open (IN1, "$ARGV[0]");
open (OUT, ">gene_call");

	print OUT "gene_callers_id\tcontig\tstart\tstop\tdirection\tpartial\tsource\tversion\n";
system ("cat $ARGV[0] | cut -f1,7,8 > tmp1");
system ("sort -u tmp1 > tmp2");

open (IN2, "<tmp2");
	
$count =1;

while (<IN2>) {
	chomp;
	$_ =~ /^(\S+)\t(\S+)\t(\S+)/;
	if ($2 < $3) {
	$left = $2-1;
	$right = $3 ;
	print OUT "$count\t$1\t$left\t$right\tf\t0\thercules\t1.0\n";
	$count ++;
 } else {
	$left = $3 -1;	
	$right = $2;
	print OUT "$count\t$1\t$left\t$right\tr\t0\thercules\t1.0\n";
	$count ++;
}

}


system ("rm tmp1 tmp2");
system ("rm combined_blast_result");

#!/usr/bin/perl

open (IN1, "$ARGV[0]");
open (IN2, "$ARGV[1]");
open (IN3, "$ARGV[2]");
open (IN4, "$ARGV[3]");
open (OUT, ">tmp0");

while (<IN1>) {
	chomp;
	$_ =~ /^(\S+)/;
	$hash1{"$1"} =1;
	print OUT "$_\n";

}


while (<IN2>) {
	chomp;
	$_ =~ /^(\S+)/;
	$hash2{"$1"} =1;
	 if  ($hash1{"$1"}) {
}else {
	print OUT "$_\n";	

}
}


while (<IN3>) {
	chomp;
	$_ =~ /^(\S+)/;
        $hash3{"$1"} =1;
	if ($hash1{"$1"})  {
} elsif ($hash2{"$1"}) {

} else {
	print OUT "$_\n";
}
}

while (<IN4>) {
	chomp;
        $_ =~ /^(\S+)/;
	if ($hash1{"$1"}) {
} elsif ($hash2{"$1"}) {

} elsif ($hash2{"$1"}) {

} else  {
	print OUT "$_\n";
} 
}

system ("sort tmp0> combined_blast_result");
system ("rm tmp0");
